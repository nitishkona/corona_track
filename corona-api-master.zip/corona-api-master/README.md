<h1 align="center">Welcome to Corona Api👋</h1>



## 🏠 Installation

OS X & Linux:

```sh
git clone https://github.com/nitishsai9/corona-api.git
cd corona-api
python3 app.py
```

Windows:

```sh
git clone https://github.com/nitishsai9/corona-api.git
cd corona-api
python app.py
```

### ✨ [Demo](https://api-corona.herokuapp.com/)
<h2> click Here to View the 

## Show your support
NitishSaikommaraju – [@Nitishsaik](https://twitter.com/Nitishsaik) – kommaraju.nitish.9@gmail.com
<br/>
[https://github.com/nitishsai9](https://github.com/nitishsai9/)

### 🤝 Contributing

1. Fork it (<https://github.com/nitishsai9/corona-api>)
2. Create your feature branch (`git checkout -b "branchname"`)
3. Commit your changes (`git commit -am 'Add some fooBar'`)
4. Push to the branch (`git push origin`)
5. Create a new Pull Request


